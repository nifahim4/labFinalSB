package com.labfinal.front;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrontApplicationTests {

	@Test
	void contextLoads() {
	}

}

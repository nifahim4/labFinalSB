document.addEventListener('DOMContentLoaded', function() {
    fetch('/api/products')
        .then(response => response.json())
        .then(products => {
            const tbody = document.querySelector('#productTable tbody');
            tbody.innerHTML = '';
            products.forEach(product => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${product.id}</td>
                    <td>${product.name}</td>
                    <td>${product.price}</td>
                `;
                tbody.appendChild(tr);
            });
        })
        .catch(error => {
            console.error('Error fetching products:', error);
            const tbody = document.querySelector('#productTable tbody');
            tbody.innerHTML = '<tr><td colspan="3" style="color:red;">Failed to load products.</td></tr>';
        });
});